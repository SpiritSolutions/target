import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmlwdHY=')

name = b.b64decode('SVBUVg==')

host = b.b64decode('aHR0cDovL29udGFyZ2V0LmxpdmU=')

port = b.b64decode('ODA4MA==')